namespace StadiaRumble;

public partial class App : System.Windows.Application
{
}
