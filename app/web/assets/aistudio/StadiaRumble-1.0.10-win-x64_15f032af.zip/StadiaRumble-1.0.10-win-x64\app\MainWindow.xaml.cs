using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace StadiaRumble;

public partial class MainWindow : Window
{
    private const uint ErrorSuccess = 0;
    private const int VibrationDurationTicks = 10;
    private readonly DispatcherTimer _scanTimer = new() { Interval = TimeSpan.FromMilliseconds(750) };
    private readonly DispatcherTimer _testTimer = new() { Interval = TimeSpan.FromMilliseconds(150) };
    private int? _activeSlot;
    private int _remainingPulses;
    private bool _isClosing;
    private bool _isTestRunning;

    public MainWindow()
    {
        InitializeComponent();
        _scanTimer.Tick += (_, _) => RefreshControllers();
        _testTimer.Tick += TestTimer_Tick;
        Loaded += (_, _) =>
        {
            RefreshControllers();
            _scanTimer.Start();
        };
    }

    private void RefreshControllers()
    {
        var previousSlot = (ControllerSelector.SelectedItem as ControllerOption)?.Index;
        var connected = Enumerable.Range(0, 4)
            .Where(IsConnected)
            .Select(index => new ControllerOption(index))
            .ToList();

        if (_activeSlot.HasValue && !connected.Any(item => item.Index == _activeSlot.Value))
        {
            _activeSlot = null;
            _isTestRunning = false;
            _testTimer.Stop();
            StopButton.IsEnabled = false;
        }

        ControllerSelector.ItemsSource = connected;
        ControllerSelector.SelectedItem = connected.FirstOrDefault(item => item.Index == previousSlot)
                                          ?? connected.FirstOrDefault();
        ControllerSelector.IsEnabled = connected.Count > 0 && !_isTestRunning;
        TestButton.IsEnabled = connected.Count > 0 && !_isTestRunning;
        RefreshButton.IsEnabled = !_isTestRunning;

        ConnectionStatus.Text = connected.Count switch
        {
            0 => "XInput-геймпад не найден. Проверь Bluetooth и установку драйвера.",
            1 => "Контроллер подключён и готов к проверке.",
            _ => $"Подключено контроллеров: {connected.Count}."
        };

        if (_isTestRunning && _activeSlot is int activeSlot && connected.All(item => item.Index != activeSlot))
        {
            ActionStatus.Text = "Контроллер был отключён во время теста. Тест остановлен.";
        }
    }

    private static bool IsConnected(int index)
    {
        return XInputGetState((uint)index, out _) == ErrorSuccess;
    }

    private void TestButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isClosing || _isTestRunning)
        {
            return;
        }

        if (ControllerSelector.SelectedItem is not ControllerOption selected)
        {
            ActionStatus.Text = "Сначала подключи контроллер и дождись его появления.";
            return;
        }

        var amount = (ushort)Math.Clamp(Math.Round(StrengthSlider.Value * ushort.MaxValue / 100), 1, ushort.MaxValue);
        var result = SetVibration(selected.Index, amount, amount);
        if (result != ErrorSuccess)
        {
            ActionStatus.Text = $"Не удалось запустить вибрацию (код {result}). Проверь Bluetooth и повторно подключи контроллер.";
            RefreshControllers();
            return;
        }

        _activeSlot = selected.Index;
        _remainingPulses = VibrationDurationTicks;
        _isTestRunning = true;
        TestButton.IsEnabled = false;
        StopButton.IsEnabled = true;
        ActionStatus.Text = "Идёт тест вибрации…";
        _testTimer.Start();
    }

    private void TestTimer_Tick(object? sender, EventArgs e)
    {
        _remainingPulses--;
        if (_remainingPulses <= 0)
        {
            StopVibration("Тест завершён.");
        }
    }

    private void StopButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isClosing)
        {
            return;
        }

        StopVibration("Вибрация остановлена.");
    }

    private void RefreshButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isClosing || _isTestRunning)
        {
            return;
        }

        ActionStatus.Text = "Проверка подключения…";
        RefreshControllers();
    }

    private void StopVibration(string message)
    {
        _testTimer.Stop();
        _isTestRunning = false;
        if (_activeSlot is int slot)
        {
            SetVibration(slot, 0, 0);
        }

        _activeSlot = null;
        StopButton.IsEnabled = false;
        RefreshButton.IsEnabled = true;
        TestButton.IsEnabled = ControllerSelector.ItemsSource is ICollection<ControllerOption> controllers && controllers.Count > 0;
        ActionStatus.Text = message;
        RefreshControllers();
    }

    private static uint SetVibration(int index, ushort left, ushort right)
    {
        var vibration = new XInputVibration { LeftMotorSpeed = left, RightMotorSpeed = right };
        return XInputSetState((uint)index, ref vibration);
    }

    private void StrengthSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (StrengthLabel is not null)
        {
            StrengthLabel.Text = $"Сила вибрации: {Math.Round(e.NewValue)}%";
        }
    }

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        _isClosing = true;
        _scanTimer.Stop();
        _testTimer.Stop();
        StopVibration("Вибрация остановлена.");
    }

    [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")]
    private static extern uint XInputGetState(uint userIndex, out XInputState state);

    [DllImport("xinput1_4.dll", EntryPoint = "XInputSetState")]
    private static extern uint XInputSetState(uint userIndex, ref XInputVibration vibration);

    [StructLayout(LayoutKind.Sequential)]
    private struct XInputState
    {
        public uint PacketNumber;
        public XInputGamepad Gamepad;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct XInputGamepad
    {
        public ushort Buttons;
        public byte LeftTrigger;
        public byte RightTrigger;
        public short LeftThumbX;
        public short LeftThumbY;
        public short RightThumbX;
        public short RightThumbY;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct XInputVibration
    {
        public ushort LeftMotorSpeed;
        public ushort RightMotorSpeed;
    }

    private sealed record ControllerOption(int Index)
    {
        public string DisplayName => $"XInput-геймпад {Index + 1}";
    }
}
